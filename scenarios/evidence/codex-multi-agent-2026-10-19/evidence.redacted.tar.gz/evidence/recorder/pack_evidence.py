"""Archive original evidence locally and a privacy-redacted inspection mirror for the PR."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile
import experiment as e

OUT=Path('/private/tmp/ads-native-ma-report-20261019/scenarios/evidence/codex-multi-agent-2026-10-19')
PUBLIC=e.ROOT/'public-capsule'

def sha(data):return hashlib.sha256(data).hexdigest()
def manifest(root,name):
    files=[p for p in sorted(root.rglob('*')) if p.is_file() and p.name!=name]
    (root/name).write_text(''.join(sha(p.read_bytes())+'  '+str(p.relative_to(root))+'\n' for p in files))
def compress(root,dest):
    with tarfile.open(dest,'w:gz') as tar:tar.add(root,arcname='evidence')
    Path(str(dest)+'.sha256').write_text(sha(dest.read_bytes())+'  '+dest.name+'\n')

e.save(e.E/'preparation-attempts.json',dict(provenance='Transcribed outer tool results; these are not invented native Agent events.',attempts=[
    dict(command='git fetch origin '+e.PIN,cwd='/Users/ian/Desktop/Projects/ADS',exit_code=255,
         output="error: cannot open '.git/FETCH_HEAD': Operation not permitted",effect='Fetch retried only in the isolated clone; original checkout unchanged.'),
    dict(command='python3 -B experiment.py suite',exit_code=1,
         output="AssertionError: global policy drift before session",effect='Stopped before first test Agent; native metadata read had already succeeded.'),
    dict(command='gh issue view 12 --repo Skyline-Gazer/ADS --json title,body,state,url',exit_code=1,
         output='error connecting to api.github.com; check your internet connection or https://githubstatus.com',
         effect='Public issue subsequently read with the available GitHub connector; no CLI authentication store read.'),
    dict(command='web open official markdown documentation',output='Unsupported content-type: text/markdown',
         effect='HTML official documentation had already been retrieved; failed markdown fetch not counted as support.'),
    dict(command='operator JSON summary helper',exit_code=1,output="TypeError: 'map' object is not subscriptable",
         effect='Corrected read-only formatting helper; no test or source state changed.')]))
e.save(e.E/'official-sources.json',dict(retrieved_date='2026-10-19',sources=[
    'https://learn.chatgpt.com/docs/agent-configuration/subagents',
    'https://learn.chatgpt.com/docs/agent-approvals-security'],
    role='Documentation context only; local native session evidence establishes installed-version behavior.'))
e.save(e.E/'recorder-provenance.json',dict(source_version='Final artifact sources; exact startup recorder digest NOT OBSERVED.',
    scope='Sequential CLI launch/timing and offline evidence checks only; native Codex parents performed all delegation.',
    edits='Recorder gained child activity trace collection during the initial suite, a separate late edge-repair path afterward, and exact removal of the outer-tool delivery approval rule. Native original JSONL was not rewritten.',
    raw_sources='Native session copies and all per-run command vectors retain original bytes; manifests identify their hashes.'))
for name in ['experiment.py','audit_native.py','postcheck.py','build_report.py','pack_evidence.py']:
    p=e.E/'recorder'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(e.ROOT/name,p)
manifest(e.E,'manifest.sha256')
compress(e.E,Path('/private/tmp/ads-native-ma-20261019.raw-evidence.tar.gz'))

redactions=[]
def walk(value,path=''):
    if isinstance(value,list):return [walk(v,path+'/'+str(i)) for i,v in enumerate(value)]
    if not isinstance(value,dict):return value
    result={}
    redact_message=value.get('type')=='message' and value.get('role') in ['developer','system']
    for key,item in value.items():
        ptr=path+'/'+key
        if key in ['creator_user_id','creator_account_id','base_instructions','developer_instructions','system_instructions'] or (key=='content' and redact_message):
            if item is not None:
                redactions.append(dict(pointer=ptr,original_value_sha256=sha(json.dumps(item,sort_keys=True).encode())))
                result[key]='[REDACTED: account metadata or unrelated host instructions]'
            else:result[key]=None
        else:result[key]=walk(item,ptr)
    return result

provenance=[]
for p in sorted(e.E.rglob('*')):
    if not p.is_file() or p.name=='manifest.sha256':continue
    dest=PUBLIC/p.relative_to(e.E);dest.parent.mkdir(parents=True,exist_ok=True)
    data=p.read_bytes();exported=data;before=len(redactions)
    if p.suffix in ['.json','.jsonl']:
        if p.suffix=='.jsonl':
            rows=[]
            for line in data.decode().splitlines():
                obj=json.loads(line)
                # Receipt streams embed the actual JSON event as a string.
                if 'raw' in obj:
                    try:obj['raw']=json.dumps(walk(json.loads(obj['raw'])),ensure_ascii=False)
                    except (ValueError,TypeError):pass
                rows.append(json.dumps(walk(obj),ensure_ascii=False))
            exported=('\n'.join(rows)+'\n').encode()
        else:exported=(json.dumps(walk(json.loads(data)),ensure_ascii=False,indent=2)+'\n').encode()
    dest.write_bytes(exported)
    if exported!=data:
        provenance.append(dict(file=str(p.relative_to(e.E)),original_sha256=sha(data),exported_sha256=sha(exported),
                               redactions=redactions[before:]))
shutil.copy2(e.E/'manifest.sha256',PUBLIC/'original-manifest.sha256')
e.save(PUBLIC/'redaction-provenance.json',dict(original_archive='/private/tmp/ads-native-ma-20261019.raw-evidence.tar.gz',
    modified_files=provenance,note='JSON may also be reserialized; original and exported hashes are distinct. Full original bytes remain local.'))
manifest(PUBLIC,'manifest.sha256')
OUT.mkdir(parents=True,exist_ok=True)
compress(PUBLIC,OUT/'evidence.redacted.tar.gz')
print('Original and redacted capsules written; redacted fields',len(redactions),'public bytes',(OUT/'evidence.redacted.tar.gz').stat().st_size)
