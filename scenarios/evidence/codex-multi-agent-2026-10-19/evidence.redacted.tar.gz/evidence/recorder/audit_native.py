"""Offline independent audit of named native sessions and deterministic evidence."""
from pathlib import Path
import collections
import datetime as dt
import hashlib
import json
import re
import sys
import experiment as e

def stamp(s): return dt.datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
def overlap(a,b): return max(0,min(a[1],b[1])-max(a[0],b[0]))
assert overlap((0,5),(3,8))==2 and overlap((0,2),(3,4))==0

def audit(name):
    ix=e.collect_trace(name)
    root_id=json.loads((e.E/(name+'.jsonl')).read_text().splitlines()[0])['thread_id']
    assert root_id in ix
    records={}
    for sid,item in ix.items():
        assert item['state']=='COPIED',(sid,item)
        path=e.E/item['target']; data=path.read_bytes()
        assert hashlib.sha256(data).hexdigest()==item['sha256']
        records[sid]=[json.loads(line) for line in data.decode().splitlines()]
    root=records[root_id];activities=[]
    for x in root:
        p=x.get('payload',{});item=p.get('item',{})
        if item.get('type')=='SubAgentActivity':
            activities.append(dict(timestamp=x['timestamp'],**item))
    children={}
    for a in activities:
        sid=a['agent_thread_id']
        children.setdefault(sid,dict(path=a['agent_path'],events=[]))['events'].append(a)
    all_response_ids=set();threads=[];unique_usage=collections.Counter()
    for sid,xs in records.items():
        meta=next(x['payload'] for x in xs if x['type']=='session_meta' and x['payload'].get('id')==sid)
        is_root=sid==root_id
        if not is_root:
            assert meta['parent_thread_id']==root_id
            assert meta['source']['subagent']['thread_spawn']['parent_thread_id']==root_id
        usage=collections.Counter();response_count=0;commands=[];calls=[];settings=[];messages=[]
        for x in xs:
            p=x.get('payload',{})
            if x['type']=='token_usage_record' and p.get('thread_id')==sid:
                key=p['response_id']
                if key in all_response_ids:continue
                all_response_ids.add(key);response_count+=1;usage.update(p['usage']);unique_usage.update(p['usage'])
            item=p.get('item',{})
            if p.get('type')=='item_completed' and item.get('type')=='CommandExecution':
                commands.append(dict(timestamp=x['timestamp'],command=item.get('command'),cwd=item.get('cwd'),
                    exit_code=item.get('exit_code'),status=item.get('status'),output=item.get('aggregated_output')))
            if p.get('type') in ['function_call','custom_tool_call']:
                calls.append(dict(timestamp=x['timestamp'],name=p.get('name'),arguments=p.get('arguments',p.get('input'))))
            if p.get('type')=='thread_settings_applied' or x['type']=='turn_context':
                settings.append(dict(timestamp=x['timestamp'],payload=p))
            if p.get('type')=='agent_message':messages.append(dict(timestamp=x['timestamp'],text=p.get('message')))
        if is_root:interval=(stamp(xs[0]['timestamp']),stamp(xs[-1]['timestamp']))
        else:
            events=children[sid]['events']
            started=next(a['timestamp'] for a in events if a['kind']=='started')
            endings=[a['timestamp'] for a in events if a['kind'] in ['completed','interrupted']]
            ended=endings[0] if endings else xs[-1]['timestamp']
            interval=(stamp(started),stamp(ended))
            children[sid].update(started_utc=started,ended_utc=ended,seconds=interval[1]-interval[0],
                 own_trace_first_utc=xs[0]['timestamp'],own_trace_last_utc=xs[-1]['timestamp'])
        turns=[]
        for x in xs:
            p=x.get('payload',{})
            if p.get('type')=='task_started' and (is_root or p.get('turn_attribution',{}).get('parent_turn_id')):
                turns.append(dict(turn_id=p['turn_id'],started_utc=x['timestamp'],ended_utc=None))
            if p.get('type') in ['task_complete','turn_aborted']:
                for turn in turns:
                    if turn['turn_id']==p.get('turn_id'):turn.update(ended_utc=x['timestamp'],state=p['type'])
        if not is_root:children[sid]['own_turns']=turns
        threads.append(dict(id=sid,parent=meta.get('parent_thread_id'),source=meta['source'],
            path=meta.get('agent_path','/root'),cwd=meta.get('cwd'),version=meta['cli_version'],
            response_count=response_count,tokens=dict(usage),interval=interval,own_turns=turns,commands=commands,calls=calls,settings=settings,messages=messages))
    intervals=[(sid,(stamp(c['started_utc']),stamp(c['ended_utc']))) for sid,c in children.items()]
    overlaps=[dict(a=a,b=b,seconds=overlap(ia,ib),start_utc=dt.datetime.fromtimestamp(max(ia[0],ib[0]),dt.timezone.utc).isoformat(),
                   end_utc=dt.datetime.fromtimestamp(min(ia[1],ib[1]),dt.timezone.utc).isoformat())
              for i,(a,ia) in enumerate(intervals) for b,ib in intervals[i+1:] if overlap(ia,ib)>0]
    if name.endswith('-serial'):assert not children,'serial run delegated'
    else:assert len(children)==2 and overlaps, (name,children,overlaps)
    result=dict(name=name,root_id=root_id,children=children,overlaps=overlaps,threads=threads,
                total_observed_model_usage=dict(unique_usage),telemetry_boundary='Unique token_usage_record response_id records, filtered to each owning thread_id; includes actual child inference and cache-read tokens, excludes operator/audit context, no spend or tool charges observed.')
    e.save(e.E/(name+'.native-audit.json'),result)
    return result

if __name__=='__main__':
    results=[]
    names=sys.argv[1:] or [p.name.removesuffix('.result.json') for p in sorted(e.E.glob('*.result.json'))]
    for name in names:
        r=audit(name);results.append(dict(name=name,root_id=r['root_id'],children=list(r['children']),
             overlap_seconds=[x['seconds'] for x in r['overlaps']],usage=r['total_observed_model_usage']))
    e.save(e.E/'native-audit-summary.json',results)
    print(json.dumps(results,indent=2))
