"""Local-only archive/export step; no execution engine or third-party dependencies."""
from pathlib import Path
import gzip
import io
import json
import re
import tarfile
import lab as l

PUBLIC=l.ROOT/'report/scenarios/evidence/claude-multi-agent-2026-10-20'
def fingerprint(value):
    data=json.dumps(value,ensure_ascii=False,sort_keys=True).encode()
    return dict(redacted=True,original_sha256=l.sha(data),original_bytes=len(data))
def redact(value):
    if isinstance(value,str):
        return value.replace('/Users/REDACTED','/Users/REDACTED')
    if isinstance(value,list):return [redact(v) for v in value]
    if not isinstance(value,dict):return value
    if value.get('type')=='prompt_snapshot':
        return dict(type='prompt_snapshot',redacted_payload=fingerprint(value))
    out={}
    for k,v in value.items():
        if k in ['systemPrompt','system_prompt','systemTurns','cliPrefix']:
            out[k]=fingerprint(v)
        elif k in ['thinking','signature','data'] and value.get('type') in ['thinking','redacted_thinking']:
            out[k]=fingerprint(v)
        elif k=='plugins':out[k]=fingerprint(v)
        elif k in ['skills','slash_commands','agents'] and value.get('subtype')=='init':
            out[k]=[redact(a) for a in v if any(s in str(a) for s in ['deliver','recover','ads-worker','ads-reader'])]
            out[k+'_unrelated_redacted']=True
        elif k=='raw' and isinstance(v,str):
            try:out[k]=json.dumps(redact(json.loads(v)),ensure_ascii=False)
            except ValueError:out[k]=redact(v)
        elif k=='content' and value.get('path','').startswith('/Users/'):
            out[k]=fingerprint(v)
        else:out[redact(k)]=redact(v)
    return out
def export(data,suffix):
    content=data.decode()
    if suffix=='.json':return (json.dumps(redact(json.loads(content)),ensure_ascii=False,indent=2)+'\n').encode()
    if suffix=='.jsonl':return ''.join(json.dumps(redact(json.loads(s)),ensure_ascii=False)+'\n' for s in content.splitlines() if s.strip()).encode()
    return redact(content).encode()
def archive(path,entries):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('wb') as out,gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as z,tarfile.open(fileobj=z,mode='w') as t:
        for name,data in sorted(entries.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
            t.addfile(info,io.BytesIO(data))
def main():
    sources={str(p.relative_to(l.ROOT)):p.read_bytes() for p in sorted(l.E.rglob('*')) if p.is_file()}
    for name in ['lab.py','execute.py','audit.py','pack.py','summarize.py','watch_recovery.py','fixture.local.bundle']:
        p=l.ROOT/name
        if p.exists():sources[name]=p.read_bytes()
    rawmanifest={name:dict(sha256=l.sha(data),bytes=len(data)) for name,data in sources.items()}
    sources['RAW-MANIFEST.json']=(json.dumps(rawmanifest,indent=2)+'\n').encode()
    raw=l.ROOT/'raw-evidence.local.tar.gz';archive(raw,sources);raw.chmod(0o600)
    exported={};provenance={}
    for name,data in sources.items():
        if name=='fixture.local.bundle':continue
        result=export(data,Path(name).suffix)
        exported[name]=result
        provenance[name]=dict(original_sha256=l.sha(data),export_sha256=l.sha(result),original_bytes=len(data),export_bytes=len(result))
    exported['EXPORT-MANIFEST.json']=(json.dumps(provenance,indent=2)+'\n').encode()
    target=PUBLIC/'evidence.redacted.tar.gz';archive(target,exported)
    # Verify each exported member after extraction and scan for the fixture canary.
    canary=(l.ROOT/'ads/app/safety/credentials.fixture').read_bytes().strip()
    secret_patterns=[rb'sk-ant-[A-Za-z0-9_-]{20,}',rb'sk-[A-Za-z0-9]{20,}',rb'gh[pousr]_[A-Za-z0-9]{20,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
    with tarfile.open(target) as t:
        for member in t.getmembers():
            data=t.extractfile(member).read();assert canary not in data,member.name
            assert not any(re.search(pattern,data) for pattern in secret_patterns),member.name
            if member.name in provenance:assert l.sha(data)==provenance[member.name]['export_sha256']
    result=dict(recorded_utc=l.now(),raw_archive_path=str(raw),raw_archive_sha256=l.sha(raw.read_bytes()),
      public_archive_sha256=l.sha(target.read_bytes()),raw_files=len(sources),public_files=len(exported),
      redaction='User home path, model thinking/signatures, system prompt snapshots, unrelated plugin/skill metadata and external instruction content. Native IDs/times, tool requests/results, source patches, failures, permission settings and token counters retained. Synthetic canary scan passed.',
      archive_member_hash_verification='PASS',synthetic_canary_export_scan='PASS')
    l.save(PUBLIC/'archive.json',result)
    (PUBLIC/'SHA256SUMS').write_text(result['public_archive_sha256']+'  evidence.redacted.tar.gz\n')
    l.save(l.ROOT/'archive.local.json',result)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
