"""Read-only process observation of the three explicitly owned blocked-task markers."""
import json
import time
import lab as l

records={};start=time.monotonic()
while time.monotonic()-start<3600:
    for trial in range(1,4):
        name='recovery-multi-'+str(trial)
        p=l.ROOT/'workspaces'/name/'.tmp/blocked-started.json'
        if not p.exists():continue
        r=records.setdefault(name,dict(marker_observations=[],source_sha256=l.sha(open(__file__,'rb').read())))
        if r.get('terminal_observed'):continue
        try:marker=json.loads(p.read_text())
        except (ValueError,OSError):continue
        pid=marker.get('pid') or marker.get('PID')
        if not isinstance(pid,int) or pid<=1:continue
        process=l.command(['ps','-p',str(pid),'-o','pid=,lstart=,command='])
        alive=process['exit_code']==0 and bool(process['stdout'].strip())
        if not r['marker_observations'] or alive!=r['marker_observations'][-1]['alive']:
            r['marker_observations'].append(dict(observed_utc=l.now(),marker=marker,alive=alive,process=process))
            if not alive:r['terminal_observed']=True
            l.save(l.E/(name+'.operator-process-watch.json'),r)
            print(name,'PID',pid,'alive',alive,flush=True)
    if len(records)==3 and all(r.get('terminal_observed') for r in records.values()):break
    time.sleep(.2)
