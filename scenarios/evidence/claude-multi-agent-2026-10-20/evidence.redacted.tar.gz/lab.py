"""Temporary Claude native acceptance evidence recorder, not ADS infrastructure."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import subprocess as sp
import time

ROOT=Path(__file__).resolve().parent
E=ROOT/'evidence'
PIN='0a91631620008c96b63981b6572d8efad9fa709f'
CLAUDE='/opt/homebrew/bin/claude'
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def command(args,cwd=ROOT,timeout=40):
    start=time.monotonic()
    p=sp.run(args,cwd=cwd,env=ENV,text=True,capture_output=True,timeout=timeout)
    return dict(command=args,cwd=str(cwd),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start)
def checked(args,cwd=ROOT):
    r=command(args,cwd);assert r['exit_code']==0,r
    return r['stdout'].strip()
def sha(data):return hashlib.sha256(data).hexdigest()
def snapshot():
    home=Path('/Users/REDACTED')
    paths={home/'.claude.json',home/'.claude/settings.json',home/'.claude/settings.local.json',home/'.claude/CLAUDE.md',
      home/'.claude/managed-settings.json',Path('/Library/Application Support/ClaudeCode/managed-settings.json'),
      home/'.codex/config.toml',home/'.codex/rules/default.rules',home/'.codex/RTK.md',home/'.codex/AGENTS.md'}
    for base in [home/'.claude/agents',home/'.claude/rules',home/'.claude/skills',home/'.claude/commands',home/'.claude/hooks',home/'.codex/rules']:
        paths.add(base)
        for directory,dirs,files in os.walk(base,followlinks=False):paths.update(Path(directory)/n for n in dirs+files)
    for p in list(paths):
        if p.is_symlink() and p.is_dir():
            for directory,dirs,files in os.walk(p.resolve(),followlinks=False):paths.update(Path(directory)/n for n in dirs+files)
    result={}
    for p in sorted(paths):
        if not p.exists() and not p.is_symlink():result[str(p)]={'exists':False};continue
        s=p.lstat();item=dict(mode=s.st_mode&0o777,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
        if p.is_symlink():item.update(kind='symlink',sha256=sha(os.readlink(p).encode()))
        elif p.is_file():
            data=p.read_bytes();item.update(kind='file',sha256=sha(data))
            if p==home/'.claude.json':
                state=json.loads(data);state.pop('skillUsage',None)
                item['policy_sha256']=sha(json.dumps(state,sort_keys=True,separators=(',',':')).encode())
        else:item['kind']='directory'
        result[str(p)]=item
    return result
def diff(a,b):return [k for k in sorted(a.keys()|b.keys()) if a.get(k)!=b.get(k)]

if __name__=='__main__':
    E.mkdir(parents=True,exist_ok=True)
    if not (E/'operator-start-policy.json').exists():save(E/'operator-start-policy.json',snapshot())
    save(E/'discovery.json',dict(recorded_utc=now(),executable=CLAUDE,executable_sha256=sha(Path(CLAUDE).read_bytes()),
      commands=[command(x) for x in [[CLAUDE,'--version'],[CLAUDE,'--help'],[CLAUDE,'agents','--help'],[CLAUDE,'auth','status','--help'],['python3','--version'],['git','--version'],['sw_vers'],['uname','-m']]]))
    print('Initial policy fingerprints and full CLI discovery recorded; no configuration content or credentials copied.')
