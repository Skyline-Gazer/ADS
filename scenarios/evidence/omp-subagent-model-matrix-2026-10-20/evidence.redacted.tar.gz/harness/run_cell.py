#!/usr/bin/env python3
"""One-shot cell runner for ADS #21. Throwaway harness, not shipped."""
import argparse, json, os, pathlib, subprocess, time, hashlib, sys

ROOT = pathlib.Path('/tmp/ads21')
H = ROOT / 'harness'

def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('cell')
    ap.add_argument('--model', required=True)
    ap.add_argument('--mode', choices=['serial','multi'], required=True)
    ap.add_argument('--overlay', required=True)
    ap.add_argument('--timeout', type=int, default=1500)
    ap.add_argument('--prompt')
    a = ap.parse_args()

    cell_dir = ROOT/'cells'/a.cell
    sess = H/'sessions'/a.cell
    out = H/'results'/a.cell
    sess.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    tools = 'read,grep,glob,edit,write,bash,todo'
    if a.mode == 'multi':
        tools += ',task,wait'
    prompt_file = pathlib.Path(a.prompt) if a.prompt else H/'prompts'/(a.mode+'.md')
    prompt = prompt_file.read_text()
    cmd = ['omp','-p','--mode','json','--no-title',
           '--session-dir', str(sess),
           '--config', str(H/'overlays'/a.overlay),
           '--plugin-dir', str(H/'plugin'),
           '--no-extensions','--no-skills','--no-rules','--no-lsp',
           '--tools', tools, '--model', a.model, '--thinking','high',
           '--max-time', str(a.timeout), prompt]
    meta = {
        'cell': a.cell, 'model': a.model, 'mode': a.mode, 'overlay': a.overlay,
        'tools': tools, 'prompt_sha256': sha(prompt_file), 'prompt_file': prompt_file.name,
        'overlay_sha256': sha(H/'overlays'/a.overlay),
        'agent_sha256': sha(H/'plugin'/'agents'/'MatrixWorker.md'),
        'cwd': str(cell_dir), 'fixture_head': subprocess.check_output(
            ['git','-C',str(cell_dir),'rev-parse','HEAD']).decode().strip(),
        'fixture_dirty_before': subprocess.check_output(
            ['git','-C',str(cell_dir),'status','--porcelain']).decode(),
        'command': cmd[:-1], 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    (out/'meta.json').write_text(json.dumps(meta, indent=2))
    t0 = time.monotonic()
    with open(out/'events.jsonl','wb') as fo, open(out/'stderr.txt','wb') as fe:
        p = subprocess.run(cmd, cwd=cell_dir, stdout=fo, stderr=fe)
    dur = time.monotonic() - t0
    meta['rc'] = p.returncode
    meta['wall_seconds'] = round(dur, 3)
    meta['finished_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    meta['fixture_dirty_after'] = subprocess.check_output(
        ['git','-C',str(cell_dir),'status','--porcelain']).decode()
    meta['fixture_diff_stat'] = subprocess.check_output(
        ['git','-C',str(cell_dir),'diff','--stat']).decode()
    (out/'meta.json').write_text(json.dumps(meta, indent=2))
    print(json.dumps({k: meta[k] for k in ('cell','rc','wall_seconds','fixture_dirty_after','fixture_diff_stat')}, indent=2))

if __name__ == '__main__':
    main()
